"FiveM Loading Screen with Music" by Skeeze415

Credit to these people below, I took parts from both projects to 
make this project. Links to Creators and projects below:

*FiveM-Material_Load-Loading-Screen:
Made by Loqrin : github.com/Loqrin'
https://github.com/Loqrin/FiveM-Material_Load-Loading-Screen

*loadingscreen:
Made by Stephane OLIVERA DOS SANTOS
https://git-iut.univ-lille1.fr/oliveras/ESX-Server/tree/master/ESX-Server/resources/loadingscreen


(1). What it does:
Allows you to have a custom loading screen with image and music, (.ogg audio, not mp3)

(2). How to install:
Download and unzip folder. 
Place "loadingscreen" folder (that is in same folder with "README") in your servers "resources" folder.
Add "start loadingscreen" (without quotes) to your "server.cfg".

(3). How to add images:
It comes with a image named "loadscreen.jpg".
You can replace that image with what ever image you want,
but keep the same name. (Must be .jpg format)

(4). How to add music:
Go to loadingscreen/audio, and place new audio here.
New audio must have the same name. (.ogg audio format only)
This does not play mp3, so you will need to convert mp3's to .ogg audio file.
Change volume in "Config.json" with notepad.

(5). How to change name/title on loading screen:
Open "Index.html" with notepad. Inside at the top will be a script where you can
change the title/name of server.
Change/adjust font in "keks.css" with notepad.

(6). For Developers/Experienced:
You can add more images and music if you know how to add scripts to the index.html, and Config.json.

Feel free to use and share, give credits to those above and me if you upload anywhere else.

Enjoy!
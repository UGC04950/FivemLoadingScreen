description '[LoqScript] material_load - A material designed loading screen for RP servers. Made by Loqrin : github.com/Loqrin'

files {
    --Loading Index File--
    'LoadingScreen/index.html',
    --Loading Image Files--
    'LoadingScreen/loadscreen.jpg',
    --Loading Audio Files--
    'LoadingScreen/audio/gtavthemesong.ogg',
    --Loading Config File--
    'LoadingScreen/config.json',
    --Loading JS Files--
    'LoadingScreen/js/materialize.min.js',
    'LoadingScreen/js/material_load.js',
    'LoadingScreen/js/jquery.min.js',
    --Loading CSS Files--
    'LoadingScreen/keks.css',
    --Loading Font Files--
    'LoadingScreen/bankgothic.ttf',
}

loadscreen 'LoadingScreen/index.html'